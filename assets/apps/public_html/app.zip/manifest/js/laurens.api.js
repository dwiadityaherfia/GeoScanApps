function test(){
    alert('hahahaha');
}


function clickButtonMenu(){
    JSInterface.menuMenu();
}

function clickButtonScan(){
    JSInterface.menuScan();
}

function clickButtonPetunjuk(){
    JSInterface.menuPetunjuk();
}

function clickButtonPengembang(){
    JSInterface.menuPengembang();
}

function clickButtonKeluar(){
    JSInterface.menuKeluar();
}
